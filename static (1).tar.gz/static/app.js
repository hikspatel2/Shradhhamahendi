/* ============================================================
   SHRADDHA MEHNDI & NAIL ARTIST - MAIN JAVASCRIPT
   ============================================================ */

'use strict';

/* ── Page Loader ── */
window.addEventListener('load', () => {
  const loader = document.getElementById('page-loader');
  if (loader) {
    setTimeout(() => loader.classList.add('hidden'), 1800);
  }
});

/* ── Navbar Scroll Behavior ── */
const navbar = document.getElementById('navbar');
if (navbar) {
  const handleScroll = () => {
    navbar.classList.toggle('scrolled', window.scrollY > 60);
    // Back to top button
    const bt = document.querySelector('.back-top');
    if (bt) bt.classList.toggle('visible', window.scrollY > 400);
  };
  window.addEventListener('scroll', handleScroll, { passive: true });
  handleScroll();
}

/* ── Mobile Menu ── */
const hamburger   = document.querySelector('.hamburger');
const mobileMenu  = document.querySelector('.mobile-menu');
const menuOverlay = document.querySelector('.menu-overlay');
const mobileClose = document.querySelector('.mobile-close');

function openMenu() {
  hamburger?.classList.add('open');
  mobileMenu?.classList.add('open');
  menuOverlay?.classList.add('open');
  document.body.style.overflow = 'hidden';
}
function closeMenu() {
  hamburger?.classList.remove('open');
  mobileMenu?.classList.remove('open');
  menuOverlay?.classList.remove('open');
  document.body.style.overflow = '';
}
hamburger?.addEventListener('click', openMenu);
mobileClose?.addEventListener('click', closeMenu);
menuOverlay?.addEventListener('click', closeMenu);
document.querySelectorAll('.mobile-menu a').forEach(a => a.addEventListener('click', closeMenu));

/* ── Dark Mode Toggle ── */
(function initDarkMode() {
  const saved = localStorage.getItem('theme') || 'light';
  document.documentElement.setAttribute('data-theme', saved);
  updateToggleIcons(saved);
})();

function updateToggleIcons(theme) {
  document.querySelectorAll('.dark-toggle').forEach(btn => {
    btn.innerHTML = theme === 'dark'
      ? '<i class="fas fa-sun"></i>'
      : '<i class="fas fa-moon"></i>';
  });
}

document.querySelectorAll('.dark-toggle').forEach(btn => {
  btn.addEventListener('click', () => {
    const current = document.documentElement.getAttribute('data-theme');
    const next    = current === 'dark' ? 'light' : 'dark';
    document.documentElement.setAttribute('data-theme', next);
    localStorage.setItem('theme', next);
    updateToggleIcons(next);
  });
});

/* ── Back To Top ── */
document.querySelector('.back-top')?.addEventListener('click', () => {
  window.scrollTo({ top: 0, behavior: 'smooth' });
});

/* ── Scroll Reveal Animations ── */
const revealObserver = new IntersectionObserver((entries) => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      entry.target.classList.add('visible');
      // add stagger delay for grid children
      if (entry.target.dataset.delay) {
        entry.target.style.transitionDelay = entry.target.dataset.delay;
      }
    }
  });
}, { threshold: 0.12, rootMargin: '0px 0px -40px 0px' });

document.querySelectorAll('.reveal, .reveal-left, .reveal-right, .reveal-scale').forEach(el => {
  revealObserver.observe(el);
});

// Auto-assign stagger delays to grid children
document.querySelectorAll('.services-grid, .stats-grid, .why-grid, .testimonials-grid, .pricing-grid, .achievements-grid, .insta-grid, .video-test-grid').forEach(grid => {
  grid.querySelectorAll(':scope > *').forEach((child, i) => {
    child.classList.add('reveal');
    child.dataset.delay = `${i * 0.08}s`;
    revealObserver.observe(child);
  });
});

/* ── Animated Counters ── */
function animateCounter(el, target, duration = 2000) {
  let start = 0;
  const step = target / (duration / 16);
  const timer = setInterval(() => {
    start = Math.min(start + step, target);
    el.textContent = Math.floor(start) + (el.dataset.suffix || '');
    if (start >= target) clearInterval(timer);
  }, 16);
}

const counterObserver = new IntersectionObserver((entries) => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      const el = entry.target;
      animateCounter(el, parseInt(el.dataset.target), 2000);
      counterObserver.unobserve(el);
    }
  });
}, { threshold: 0.5 });

document.querySelectorAll('[data-target]').forEach(el => counterObserver.observe(el));

/* ── Particle Background for Hero ── */
function createParticles() {
  const container = document.querySelector('.hero-particles');
  if (!container) return;
  const count = window.innerWidth < 768 ? 15 : 30;
  for (let i = 0; i < count; i++) {
    const p = document.createElement('div');
    p.className = 'hero-particle';
    p.style.cssText = `
      left: ${Math.random() * 100}%;
      animation-duration: ${6 + Math.random() * 8}s;
      animation-delay: ${Math.random() * 6}s;
      width: ${2 + Math.random() * 4}px;
      height: ${2 + Math.random() * 4}px;
      opacity: ${0.3 + Math.random() * 0.6};
    `;
    container.appendChild(p);
  }
}
createParticles();

/* ── Gallery Filter ── */
function initGalleryFilter() {
  const filterBtns = document.querySelectorAll('.filter-btn');
  const items      = document.querySelectorAll('.masonry-item, .gallery-item');
  if (!filterBtns.length) return;

  filterBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      filterBtns.forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      const cat = btn.dataset.filter;
      items.forEach(item => {
        const show = cat === 'all' || item.dataset.category === cat;
        item.style.transition = 'opacity .35s, transform .35s';
        if (show) {
          item.style.opacity    = '1';
          item.style.transform  = 'scale(1)';
          item.style.display    = '';
        } else {
          item.style.opacity    = '0';
          item.style.transform  = 'scale(.92)';
          setTimeout(() => { if (item.style.opacity === '0') item.style.display = 'none'; }, 350);
        }
      });
    });
  });
}
initGalleryFilter();

/* ── Lightbox ── */
function initLightbox() {
  const lightbox   = document.getElementById('lightbox');
  if (!lightbox) return;
  const lbImg      = lightbox.querySelector('.lightbox-img');
  const lbClose    = lightbox.querySelector('.lightbox-close');
  const lbPrev     = lightbox.querySelector('.lightbox-prev');
  const lbNext     = lightbox.querySelector('.lightbox-next');
  let   currentIdx = 0;
  const images     = [];

  document.querySelectorAll('[data-lightbox]').forEach((el, idx) => {
    const src   = el.dataset.lightbox || el.querySelector('img')?.src || el.src;
    const label = el.dataset.label || '';
    images.push({ src, label });
    el.addEventListener('click', () => openLightbox(idx));
  });

  function openLightbox(idx) {
    currentIdx   = idx;
    lbImg.src    = images[idx].src;
    lightbox.classList.add('open');
    document.body.style.overflow = 'hidden';
  }
  function closeLightbox() {
    lightbox.classList.remove('open');
    document.body.style.overflow = '';
    setTimeout(() => { lbImg.src = ''; }, 300);
  }
  function showNext() { openLightbox((currentIdx + 1) % images.length); }
  function showPrev() { openLightbox((currentIdx - 1 + images.length) % images.length); }

  lbClose?.addEventListener('click', closeLightbox);
  lbPrev?.addEventListener('click', showPrev);
  lbNext?.addEventListener('click', showNext);
  lightbox.addEventListener('click', e => { if (e.target === lightbox) closeLightbox(); });
  document.addEventListener('keydown', e => {
    if (!lightbox.classList.contains('open')) return;
    if (e.key === 'Escape') closeLightbox();
    if (e.key === 'ArrowRight') showNext();
    if (e.key === 'ArrowLeft')  showPrev();
  });

  // Touch swipe for lightbox
  let touchStartX = 0;
  lightbox.addEventListener('touchstart', e => { touchStartX = e.touches[0].clientX; }, { passive: true });
  lightbox.addEventListener('touchend',   e => {
    const diff = touchStartX - e.changedTouches[0].clientX;
    if (Math.abs(diff) > 50) diff > 0 ? showNext() : showPrev();
  });
}
initLightbox();

/* ── Active Nav Links ── */
function setActiveNav() {
  const path = window.location.pathname.split('/').pop() || 'index.html';
  document.querySelectorAll('.nav-links a, .mobile-menu a').forEach(a => {
    const href = a.getAttribute('href') || '';
    const isActive = href === path || href === '/' && (path === '' || path === 'index.html');
    a.classList.toggle('active', isActive);
  });
}
setActiveNav();

/* ── Smooth Scroll for Anchor Links ── */
document.querySelectorAll('a[href^="#"]').forEach(a => {
  a.addEventListener('click', e => {
    const target = document.querySelector(a.getAttribute('href'));
    if (!target) return;
    e.preventDefault();
    const offset = 80;
    window.scrollTo({ top: target.offsetTop - offset, behavior: 'smooth' });
  });
});

/* ── Form Validation ── */
function initForms() {
  document.querySelectorAll('.contact-form').forEach(form => {
    form.addEventListener('submit', e => {
      e.preventDefault();
      let valid = true;

      form.querySelectorAll('[required]').forEach(field => {
        const val = field.value.trim();
        const err = field.parentElement.querySelector('.field-error');
        if (!val) {
          valid = false;
          field.style.borderColor = '#e53e3e';
          if (err) err.style.display = 'block';
        } else {
          field.style.borderColor = '';
          if (err) err.style.display = 'none';
        }
        // Email validation
        if (field.type === 'email' && val) {
          const emailRe = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
          if (!emailRe.test(val)) {
            valid = false;
            field.style.borderColor = '#e53e3e';
          }
        }
        // Phone validation
        if (field.type === 'tel' && val) {
          const phoneRe = /^[6-9]\d{9}$/;
          if (!phoneRe.test(val.replace(/\s/g,''))) {
            valid = false;
            field.style.borderColor = '#e53e3e';
          }
        }
      });

      if (valid) {
        showToast('✨ Message sent! We\'ll contact you soon.', 'success');
        form.reset();
      } else {
        showToast('⚠️ Please fill all required fields correctly.', 'error');
      }
    });

    // Live validation
    form.querySelectorAll('.form-control').forEach(field => {
      field.addEventListener('input', () => { field.style.borderColor = ''; });
    });
  });
}
initForms();

/* ── Toast Notification ── */
function showToast(message, type = 'success') {
  const existing = document.querySelector('.toast');
  if (existing) existing.remove();

  const toast = document.createElement('div');
  toast.className = `toast toast-${type}`;
  toast.innerHTML = message;
  toast.style.cssText = `
    position:fixed; bottom:5rem; left:50%; transform:translateX(-50%) translateY(20px);
    background:${type === 'success' ? 'linear-gradient(135deg,#7A3E1D,#D4A373)' : '#e53e3e'};
    color:#fff; padding:.85rem 2rem; border-radius:50px;
    font-size:.88rem; font-weight:500; z-index:9999;
    box-shadow:0 8px 32px rgba(0,0,0,.25);
    opacity:0; transition:all .4s cubic-bezier(.4,0,.2,1);
    white-space:nowrap;
  `;
  document.body.appendChild(toast);
  requestAnimationFrame(() => {
    toast.style.opacity    = '1';
    toast.style.transform  = 'translateX(-50%) translateY(0)';
  });
  setTimeout(() => {
    toast.style.opacity   = '0';
    toast.style.transform = 'translateX(-50%) translateY(20px)';
    setTimeout(() => toast.remove(), 400);
  }, 3500);
}

/* ── Scroll Progress Bar ── */
function initScrollProgress() {
  const bar = document.getElementById('scroll-progress');
  if (!bar) return;
  window.addEventListener('scroll', () => {
    const pct = (window.scrollY / (document.documentElement.scrollHeight - window.innerHeight)) * 100;
    bar.style.width = `${pct}%`;
  }, { passive: true });
}
initScrollProgress();

/* ── Lazy Loading Images ── */
if ('IntersectionObserver' in window) {
  const imgObs = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        const img = entry.target;
        if (img.dataset.src) {
          img.src = img.dataset.src;
          img.removeAttribute('data-src');
          imgObs.unobserve(img);
        }
      }
    });
  }, { rootMargin: '200px' });
  document.querySelectorAll('img[data-src]').forEach(img => imgObs.observe(img));
}

/* ── Text Typewriter for Hero ── */
function initTypewriter() {
  const el = document.querySelector('.typewriter');
  if (!el) return;
  const texts = el.dataset.texts ? JSON.parse(el.dataset.texts) : [el.textContent];
  let  textIdx = 0, charIdx = 0, deleting = false;
  el.textContent = '';

  function type() {
    const current = texts[textIdx];
    if (!deleting) {
      el.textContent = current.slice(0, ++charIdx);
      if (charIdx === current.length) {
        deleting = true;
        setTimeout(type, 2200);
        return;
      }
    } else {
      el.textContent = current.slice(0, --charIdx);
      if (charIdx === 0) {
        deleting = false;
        textIdx  = (textIdx + 1) % texts.length;
      }
    }
    setTimeout(type, deleting ? 55 : 85);
  }
  type();
}
initTypewriter();

/* ── Floating WhatsApp Pulse ── */
function initWhatsAppPulse() {
  const wa = document.querySelector('.whatsapp-float');
  if (!wa) return;
  const pulse = document.createElement('span');
  pulse.style.cssText = `
    position:absolute; inset:-4px; border-radius:50%;
    background:rgba(37,211,102,.35);
    animation:waPulse 2s ease infinite;
  `;
  wa.style.position = 'relative';
  wa.appendChild(pulse);
  const style = document.createElement('style');
  style.textContent = `
    @keyframes waPulse {
      0%   { transform:scale(1); opacity:.7; }
      70%  { transform:scale(1.5); opacity:0; }
      100% { transform:scale(1); opacity:0; }
    }
  `;
  document.head.appendChild(style);
}
initWhatsAppPulse();

/* ── Page Transition ── */
document.querySelectorAll('a:not([href^="#"]):not([href^="http"]):not([href^="mailto"]):not([href^="tel"]):not([target="_blank"])').forEach(link => {
  link.addEventListener('click', e => {
    const href = link.getAttribute('href');
    if (!href || href === '#') return;
    e.preventDefault();
    document.body.style.opacity = '0';
    document.body.style.transition = 'opacity .3s';
    setTimeout(() => { window.location.href = href; }, 280);
  });
});
// Restore opacity on new page
window.addEventListener('pageshow', () => {
  document.body.style.opacity   = '1';
  document.body.style.transition= 'opacity .4s';
});

/* ── Star Rating Visual ── */
document.querySelectorAll('.star-rating').forEach(el => {
  const n = parseInt(el.dataset.rating) || 5;
  el.innerHTML = Array(5).fill(0).map((_, i) =>
    `<i class="fa${i < n ? 's' : 'r'} fa-star" style="color:${i<n?'#C9A84C':'#ddd'}"></i>`
  ).join('');
});

/* ── Tilt Effect on Cards (desktop) ── */
if (window.innerWidth > 768) {
  document.querySelectorAll('.service-card, .pricing-card, .why-card').forEach(card => {
    card.addEventListener('mousemove', e => {
      const rect = card.getBoundingClientRect();
      const x    = (e.clientX - rect.left) / rect.width  - .5;
      const y    = (e.clientY - rect.top)  / rect.height - .5;
      card.style.transform = `translateY(-8px) rotateX(${y * -8}deg) rotateY(${x * 8}deg)`;
    });
    card.addEventListener('mouseleave', () => {
      card.style.transform = '';
      card.style.transition = 'transform .5s ease';
    });
  });
}

/* ── Hero Parallax ── */
const heroSection = document.getElementById('hero');
if (heroSection) {
  window.addEventListener('scroll', () => {
    if (window.scrollY < window.innerHeight) {
      heroSection.style.backgroundPositionY = `${window.scrollY * 0.4}px`;
    }
  }, { passive: true });
}

/* ── Cookie / Announcement Banner ── */
function initAnnouncement() {
  const banner = document.getElementById('announcement');
  if (!banner) return;
  const key    = 'announcement_dismissed';
  if (localStorage.getItem(key)) { banner.remove(); return; }
  banner.classList.add('visible');
  banner.querySelector('.banner-close')?.addEventListener('click', () => {
    banner.style.opacity = '0';
    setTimeout(() => banner.remove(), 300);
    localStorage.setItem(key, '1');
  });
}
initAnnouncement();

/* ── Testimonial Auto-Scroll ── */
function initTestimonialSlider() {
  const track = document.querySelector('.testimonial-track');
  if (!track) return;
  let pos = 0;
  setInterval(() => {
    pos += 1;
    if (pos > track.scrollWidth - track.clientWidth) pos = 0;
    track.scrollLeft = pos;
  }, 30);
}

/* ── Expose utilities globally ── */
window.showToast = showToast;

/* ── PWA Service Worker Registration ── */
if ('serviceWorker' in navigator) {
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('/static/sw.js')
      .then(reg => console.log('[PWA] Service Worker registered:', reg.scope))
      .catch(err => console.warn('[PWA] SW registration failed:', err));
  });
}

/* ── Handle booking form WhatsApp redirect ── */
document.querySelectorAll('.book-whatsapp').forEach(btn => {
  btn.addEventListener('click', () => {
    const phone   = '919876543210'; // Replace with real number
    const service = document.querySelector('#service-select')?.value || 'Mehndi/Nail Service';
    const msg     = encodeURIComponent(`Hi! I'd like to book a ${service} appointment. Please share availability.`);
    window.open(`https://wa.me/${phone}?text=${msg}`, '_blank');
  });
});
